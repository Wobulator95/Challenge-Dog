﻿using System;

namespace Challenge_Dog
{
    public enum Gender
   {
       Male,
       Female
   } 
    public class Dog
    {
        public string name;
        public string owner;
        public int age;
        public Gender gender;
        public string GetTag()
        {
            Console.WriteLine("If lost, call {0}. His name is {1} and he is {3} years old.", owner, name, age);
            return GetTag();
        }
    
        public Dog(string name, string owner, int age, Gender gender)
        {

            
        }
        static void Main(string[] args)
        {
             Dog puppy = new Dog("Orion", "Shawn", 1, Gender.Male);
            Console.WriteLine(puppy.GetTag());
        }
    }
}
